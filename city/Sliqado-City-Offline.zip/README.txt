SLIQADO CITY — OFFLINE

1. ZIP entpacken.
2. START-SLIQADO-CITY.html doppelklicken.
3. Das Spiel läuft offline im Browser.

Steuerung:
- Linksklick + Ziehen: bauen
- Rechtsklick + Ziehen: Kamera
- Touch + Ziehen: Kamera
- Mausrad: Zoom

Online: https://sliqado.org/city/
